// Authentication utility functions

class AuthManager {
    constructor() {
        this.user = null;
        this.init();
    }

    async init() {
        // Check if user is logged in on page load
        await this.checkAuth();
    }

    async checkAuth() {
        try {
            const response = await fetch('/api/auth/me');
            if (response.ok) {
                const data = await response.json();
                this.user = data.user;
                this.updateUI();
                return true;
            } else {
                this.user = null;
                this.handleUnauthorized();
                return false;
            }
        } catch (error) {
            console.error('Auth check failed:', error);
            this.user = null;
            return false;
        }
    }

    async login(username, password) {
        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();
            if (response.ok) {
                this.user = data.user;
                localStorage.setItem('user', JSON.stringify(data.user));
                this.updateUI();
                return { success: true, user: data.user };
            } else {
                return { success: false, error: data.error };
            }
        } catch (error) {
            return { success: false, error: 'Network error. Please try again.' };
        }
    }

    async logout() {
        try {
            await fetch('/api/auth/logout', {
                method: 'POST'
            });
            this.user = null;
            localStorage.removeItem('user');
            window.location.href = '/login';
        } catch (error) {
            console.error('Logout failed:', error);
            // Force logout even if request fails
            this.user = null;
            localStorage.removeItem('user');
            window.location.href = '/login';
        }
    }

    isAuthenticated() {
        return this.user !== null;
    }

    hasRole(role) {
        if (!this.user) return false;
        const roleHierarchy = {
            'user': 1,
            'admin': 2,
            'super_admin': 3
        };
        const userRole = roleHierarchy[this.user.role] || 0;
        const requiredRole = roleHierarchy[role] || 0;
        return userRole >= requiredRole;
    }

    isSuperAdmin() {
        return this.hasRole('super_admin');
    }

    isAdmin() {
        return this.hasRole('admin') || this.isSuperAdmin();
    }

    updateUI() {
        // Update UI based on authentication state
        const userInfo = document.getElementById('userInfo');
        const loginLink = document.getElementById('loginLink');
        const logoutBtn = document.getElementById('logoutBtn');

        if (this.user) {
            if (userInfo) {
                userInfo.textContent = this.user.username;
                userInfo.style.display = 'inline';
            }
            if (loginLink) loginLink.style.display = 'none';
            if (logoutBtn) logoutBtn.style.display = 'inline';
        } else {
            if (userInfo) userInfo.style.display = 'none';
            if (loginLink) loginLink.style.display = 'inline';
            if (logoutBtn) logoutBtn.style.display = 'none';
        }
    }

    handleUnauthorized() {
        // Only redirect if not already on login/signup page
        const currentPath = window.location.pathname;
        if (currentPath !== '/login' && currentPath !== '/signup') {
            // Don't redirect on API calls
            if (!currentPath.startsWith('/api')) {
                window.location.href = '/login';
            }
        }
    }

    requireAuth() {
        if (!this.isAuthenticated()) {
            window.location.href = '/login';
            return false;
        }
        return true;
    }

    requireRole(role) {
        if (!this.requireAuth()) {
            return false;
        }
        if (!this.hasRole(role)) {
            alert('You do not have permission to access this resource.');
            window.location.href = '/';
            return false;
        }
        return true;
    }
}

// Initialize global auth manager
const authManager = new AuthManager();

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AuthManager;
}

